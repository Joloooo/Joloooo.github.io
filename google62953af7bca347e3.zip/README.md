To access Test website https://jolocorp.com
To access Dev Testing website https://jolocorp.github.io/
